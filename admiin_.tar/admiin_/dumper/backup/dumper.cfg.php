<?php
$this->SET = array(
'last_action' => '1',
'last_db_backup' => 'f3abycom_f3a',
'tables' => '',
'comp_method' => '1',
'comp_level' => '2',
'last_db_restore' => 'information_schema',
'tables_exclude' => '0',
)
?>